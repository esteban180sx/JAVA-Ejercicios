package co.com.bancolombia;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {

        Biblioteca b = new Biblioteca("Biblioteca Libros melos");

        LibroElectronico l1 = new LibroElectronico("100 anios de soledad", "Gabo", 1967,"PDF",10,500,false);
        LibroElectronico l2 = new LibroElectronico("Biblia", "Varios autores", 0,"PDF",30,1000,false);
        LibroElectronico l3 = new LibroElectronico("Como usar la IA y volverte billionario", "ClaudeGPT", 2026,"PDF",1,100000,true);



        b.agregarItem(l1);
        b.agregarItem(l2);
        b.agregarItem(l3);


        System.out.println(l1.obtenerResumen() + "\n");
        System.out.println("Libro mas antiguo " + b.buscarOptimo().obtenerResumen());


    }



}
