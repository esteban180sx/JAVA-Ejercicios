package co.com.bancolombia;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {

    private String nombre;
    private List<RecursoBibliografico> items = new ArrayList<>();

    public Biblioteca(String n){
        this.nombre = n;

    }


    public RecursoBibliografico buscarOptimo(){

        int anio = 2026;
        int optimo = 0;
        for (int i=0; i<items.size();i++){
            if (items.get(i).getAnioPublicacion() <anio){
                optimo = i;
            }

        }

        return items.get(optimo);

    }

    public void agregarItem(RecursoBibliografico item){
        items.add(item);
    }

}
