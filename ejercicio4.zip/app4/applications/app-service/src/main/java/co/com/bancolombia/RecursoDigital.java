package co.com.bancolombia;



public class RecursoDigital extends RecursoBibliografico {

   private  String formato;
    private double tamanioMB;


    public RecursoDigital(String titulo, String autor, int anioPublicacion, String formato, double tamanioMB) {
        super(titulo, autor, anioPublicacion);
        this.formato = formato;
        this.tamanioMB = tamanioMB;
    }



    public String obtenerResumen(){

       return "Recurso digital " + getTitulo() + " " + getAutor() + " " + getAnioPublicacion() + "formato: " + formato + "tamanio " + tamanioMB;

    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public double getTamanioMB() {
        return tamanioMB;
    }

    public void setTamanioMB(double tamanioMB) {
        this.tamanioMB = tamanioMB;
    }
}
