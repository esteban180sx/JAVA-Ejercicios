package co.com.bancolombia;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class RecursoBibliografico {

    private String titulo;
    private String autor;
    private int anioPublicacion;

    public RecursoBibliografico(String titulo, String autor, int anioPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
    }



    public String obtenerResumen(){

        return "Recurso bibliografico " + titulo + " " + autor + " " + anioPublicacion;

    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }
}
