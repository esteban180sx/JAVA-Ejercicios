package co.com.bancolombia;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LibroElectronico extends RecursoDigital{


    private int numeroPaginas;
    private boolean tieneDRM;

    public LibroElectronico(String titulo, String autor, int anioPublicacion, String formato, double tamanioMB,int numeroPaginas,boolean tieneDRM) {
        super(titulo, autor, anioPublicacion,formato,tamanioMB);
        this.numeroPaginas = numeroPaginas;
        this.tieneDRM = tieneDRM;

    }




    public String obtenerResumen(){

        return "Libro electronico: " + getTitulo() + " " + getAutor() + " " + getAnioPublicacion() + " formato: " + getFormato() + " tamanio:" + getTamanioMB() +" numero paginas:" + numeroPaginas + " DRM: " + tieneDRM;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public boolean isTieneDRM() {
        return tieneDRM;
    }

    public void setTieneDRM(boolean tieneDRM) {
        this.tieneDRM = tieneDRM;
    }
}
