package co.com.bancolombia;

public class Moto extends Vehiculo{


    public Moto(String marca, String modelo, int anio, double precio, double kilometraje) {
        super(marca, modelo, anio, precio, kilometraje);
    }

    @Override
    public double calcularCostoViaje() {
        return kilometraje * (precio * (1-0.1));
    }
}
