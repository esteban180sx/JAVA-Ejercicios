package co.com.bancolombia;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {


        Flota flota = new Flota("F-001");

        Auto auto1 = new Auto("Mazda","RX7",1999,80000.0,10000);
        Auto auto2 = new Auto("Toyota","Corolla",2010,60000.0,10000);
        AutoElectrico auto3 = new AutoElectrico("Tesla","Model Y",2020,30000.0,10000);
        Moto m1 = new Moto("Yamaha", "R15",2017,40000,10000);

        flota.agregarItem(auto1);
        flota.agregarItem(auto2);
        flota.agregarItem(auto3);
        flota.agregarItem(m1);

        Vehiculo optimo = flota.buscarElementoOptimo();

        System.out.println("Este es el vehiculo con menor costo: " + optimo.marca +" " + optimo.modelo +" " + + optimo.anio);


    }
}
