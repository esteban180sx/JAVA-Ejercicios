package co.com.bancolombia;

public class Auto extends Vehiculo{

    int asientos;

    public Auto(String marca, String modelo, int anio, double precio, double kilometraje) {
        super(marca, modelo, anio, precio, kilometraje);
    }


    @Override
    public double calcularCostoViaje() {


        return kilometraje * precio;
    }
}
