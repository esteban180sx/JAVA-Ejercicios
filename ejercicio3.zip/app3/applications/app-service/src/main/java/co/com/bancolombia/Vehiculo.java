package co.com.bancolombia;

public abstract class Vehiculo {

    String marca;
    String modelo;
    int anio;
    double precio;
    double kilometraje;

    public Vehiculo(String marca, String modelo, int anio, double precio, double kilometraje) {
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.precio = precio;
        this.kilometraje = kilometraje;
    }

    public abstract double calcularCostoViaje();


}
