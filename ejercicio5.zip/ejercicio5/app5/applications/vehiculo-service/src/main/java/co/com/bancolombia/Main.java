package co.com.bancolombia;

import org.springframework.core.OverridingClassLoader;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {

        List<Vehiculo> vehiculos = new ArrayList<>();

        Auto auto1 = new Auto("Mazda","RX7",1999,80000.0,10000);
        Auto auto2 = new Auto("Toyota","Corolla",2010,60000.0,10000);
        AutoElectrico auto3 = new AutoElectrico("Tesla","Model Y",2020,30000.0,10000);
        Moto m1 = new Moto("Yamaha", "R15",2017,40000,10000);


        vehiculos.add(auto1);
        vehiculos.add(auto2);
        vehiculos.add(auto3);
        vehiculos.add(m1);



    }
}
