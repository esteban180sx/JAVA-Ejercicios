package co.com.bancolombia;

public interface VehiculoElectrico {

    double obtenerCapacidadBateria();
    int obtenerNivelCarga();

}
