package co.com.bancolombia;

import co.com.bancolombia.model.Flota;
import co.com.bancolombia.model.Factura;
import co.com.bancolombia.model.Vehiculo;
import co.com.bancolombia.model.Auto;
import co.com.bancolombia.model.AutoElectrico;
import co.com.bancolombia.model.Moto;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {

        Flota flota = new Flota("F-001");
        Factura ejemploCosto = new Factura();

        Auto auto1 = new Auto("Mazda","RX7",1999,80000.0,10000);
        Auto auto2 = new Auto("Toyota","Corolla",2010,60000.0,10000);
        AutoElectrico auto3 = new AutoElectrico("Tesla","Model Y",2020,30000.0,10000);
        Moto m1 = new Moto("Yamaha", "R15",2017,40000,10000);

        flota.agregarItem(auto1);
        flota.agregarItem(auto2);
        flota.agregarItem(auto3);
        flota.agregarItem(m1);

        System.out.println("Costo de recorrido de 5 mil km en Mazda RX7 " + ejemploCosto.calcularCosto(auto1,50));


    }
}
