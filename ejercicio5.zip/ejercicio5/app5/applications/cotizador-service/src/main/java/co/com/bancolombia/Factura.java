package co.com.bancolombia;

public class Factura {

    private double distancia;
    private double costoViaje;
    private Vehiculo vehiculo;




    public double calcularCosto(Vehiculo vehiculo,double distancia){
        return distancia * vehiculo.getPrecio();

    }

}
