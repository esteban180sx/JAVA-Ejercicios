package co.com.bancolombia.model;

public interface VehiculoElectrico {

    double obtenerCapacidadBateria();
    int obtenerNivelCarga();

}
