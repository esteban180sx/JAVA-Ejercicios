package co.com.bancolombia.model;

import co.com.bancolombia.model.Auto;

public class AutoElectrico extends Auto implements VehiculoElectrico{

    int capacidad;
    int carga;


    public AutoElectrico(String marca, String modelo, int anio, double precio, double kilometraje) {
        super(marca, modelo, anio, precio, kilometraje);
    }



    @Override
    public double obtenerCapacidadBateria() {
        return capacidad;
    }

    @Override
    public int obtenerNivelCarga() {
        return carga;
    }
}
