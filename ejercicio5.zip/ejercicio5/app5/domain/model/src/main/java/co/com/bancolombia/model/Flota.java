package co.com.bancolombia.model;

import java.util.ArrayList;
import java.util.List;
import co.com.bancolombia.model.Vehiculo;



public class Flota {

    private String nombre;
    private List<Vehiculo> items = new ArrayList<>();

    public Flota(String s) {
        this.nombre = s;
    }

    public void agregarItem(Vehiculo item){
        items.add(item);
    }





}
