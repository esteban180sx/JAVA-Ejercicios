package co.com.bancolombia.model;

import co.com.bancolombia.model.Vehiculo;

public class Moto extends Vehiculo {


    public Moto(String marca, String modelo, int anio, double precio, double kilometraje) {
        super(marca, modelo, anio, precio, kilometraje);
    }


}
