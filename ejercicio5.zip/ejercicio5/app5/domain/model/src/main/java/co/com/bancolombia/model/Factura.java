package co.com.bancolombia.model;

import co.com.bancolombia.model.Vehiculo;

public class Factura {

    private double distancia;
    private double costoViaje;
    private Vehiculo vehiculo;




    public double calcularCosto(Vehiculo vehiculo,double distancia){
        return distancia * vehiculo.getPrecio();

    }

}
