package co.com.bancolombia;

public interface Pagable {


    double calcularPago();

    double aplicarDescuento(double porcentaje);

    String descripcion();

}
