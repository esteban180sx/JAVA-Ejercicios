package co.com.bancolombia;


public class Producto implements Pagable, Serializable {

    private String nombre;
    private double precio;
    private int cantidad;

    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
public double calcularTotal(){
        return this.precio * (double) this.cantidad;
}

    @Override
    public double calcularPago() {
        return 0;
    }

    @Override
    public double aplicarDescuento(double porcentaje) {

        double total = calcularTotal();
        return - (total * porcentaje / 100);


    }

    @Override
    public String descripcion() {


        return String.format("Producto: %s | precio $%.2f | Cantidad %d | Total con Descuento: $%.2f",
        this.nombre, this.precio, this.cantidad, this.aplicarDescuento( 10)) ;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    @Override
    public String serializar() {
        return "";
    }
}
