package co.com.bancolombia;

public interface Serializable {

    String serializar();

}
