package co.com.bancolombia;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {


        Factura factura = new Factura("F-001");

        factura.agregarItem(new Producto("Laptop",
                999.9,1));

        factura.agregarItem(new Producto("Mouse",
                25,2));

        factura.agregarItem(new Servicio(
                "Soporte Tecnico", 80,3));


        factura.imprimir();


    }
}
