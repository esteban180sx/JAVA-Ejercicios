package co.com.bancolombia;

public interface Pagable {


    double calcularTotal();
    double aplicarDescuento(double pct);

    default String resumen() {

        return "Total: $" + calcularTotal();
    }

}